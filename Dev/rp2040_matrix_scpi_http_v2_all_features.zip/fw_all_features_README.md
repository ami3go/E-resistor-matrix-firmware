# RP2040 Matrix Firmware - All Practical Web Server Features

This firmware revision adds the practical web-server features discussed:

- Lightweight Material-style dashboard
- Wider control table with non-wrapping 16-bit indicators
- Target resistance input with nearest-mask calculation
- Safety limits and expert mode
- Profiles / presets stored in LittleFS
- Live `/state` auto-refresh panel
- Event/action log
- Calibration metadata fields
- Calibration config upload page
- Ethernet settings tab
- Runtime RAM/core-load page
- LittleFS files page
- SCPI help/status page
- Backup download
- Factory reset actions
- Watchdog/uptime page scaffold
- Color-coded resistance ranges
- SCPI `SYST:STAT?` command

Notes:
- Ethernet remains static by default: 192.168.7.50/255.255.255.0.
- Ethernet changes are stored in `/network.csv` and used on the next boot.
- Safety defaults: minimum 300 Ohm, max active bits 16, expert OFF.
- Watchdog is intentionally not enabled by default while the firmware is still being debugged.
